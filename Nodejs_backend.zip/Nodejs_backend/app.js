const express = require('express')
const bodyParser = require('body-parser')
const mysql = require('mysql')
var cors = require('cors')
const { request } = require('express')

const app = express()
const port = process.env.PORT || 1000

app.use(cors())

app.use(bodyParser.urlencoded({extended: false}))

app.use(bodyParser.json())

//sql
const pool = mysql.createPool({
  connectionLimit : 1000,
  host            : "localhost",
  user            : "root",
  password        : "",
  database        :"moviesdb",
})

//get all movies from DB
app.get('/movies', (req, res) => {
  pool.getConnection((err, connection) => {
    if(err) throw err
    console.log('connected')

    connection.query('SELECT * from movies', (err, rows) =>{
      connection.release() //return connection to pool

      if(!err){
        res.send(rows)
      }else{
        console.log(err)
      }
    })
  })
})

//Add a new movie to DB
app.post('/add', (req, res) => {

  pool.getConnection((err, connection) => {
    if(err) throw err
    console.log('connected')

    const params = req.body

    connection.query('INSERT INTO movies SET ?', params, (err, rows) => {
      connection.release(); //return connection to pool

      if(!err){
        res.send()
      }else{
        console.log(err)
      }
    })
    console.log(req.body)
  })
})


//delete movie in database

app.delete('/:m_id', (req, res) => {

  pool.getConnection((err, connection) => {
    if(err) throw err
    console.log('connected')

    connection.query('DELETE FROM movies WHERE m_id = ?', [req.params.m_id], (err, rows) =>{
    connection.release() //return connection to pool

      if(!err){
        res.send('Movie has been deleted.')
      }else{
        console.log(err)
      }
    })
  })
})

//Apdate records

//'update movies set m_title = ?, m_description = ?, m_release = ?, m_genre = ?, m_apdated_at = ? where m_id = ?'
app.put('/update', (req, res) => {
  pool.getConnection((err, connection) => {
    if(err) throw err
    console.log('connected')

     const {m_title, m_description, m_release, m_genre, m_apdated_at, m_id} = req.body

    connection.query('update movies set m_title = ?, m_description = ?, m_release = ?, m_genre = ?, m_apdated_at = ? where m_id = ?', [m_title, m_description, m_release, m_genre, m_apdated_at, m_id], (err, rows) =>{
      connection.release() //return connection to pool

      if(!err){
        res.send();
      }else{
        console.log(err)
      }
    })
    console.log(req.body)
  })
})

app.listen(port, () => console.log('listen on port:' + port))